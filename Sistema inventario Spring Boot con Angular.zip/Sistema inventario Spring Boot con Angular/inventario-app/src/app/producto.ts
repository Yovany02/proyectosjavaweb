export class Producto {
    idProducto: number;
    descripcion: string;
    precio: number;
    existencia: number;

}
